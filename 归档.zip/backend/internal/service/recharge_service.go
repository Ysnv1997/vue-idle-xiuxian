package service

import (
	"bytes"
	"context"
	"crypto/hmac"
	"crypto/sha256"
	"database/sql"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"strconv"
	"strings"
	"time"

	"github.com/google/uuid"
	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgconn"
	"github.com/jackc/pgx/v5/pgxpool"

	"github.com/kowming/vue-idle-xiuxian/backend/internal/repository"
)

const (
	rechargeStatusPending   = "pending"
	rechargeStatusPaid      = "paid"
	rechargeStatusFailed    = "failed"
	rechargeStatusCancelled = "cancelled"
)

const pgUniqueViolationCode = "23505"

type RechargeService struct {
	pool                *pgxpool.Pool
	userRepo            *repository.UserRepository
	callbackSecret      string
	checkoutURLTemplate string
}

func NewRechargeService(
	pool *pgxpool.Pool,
	userRepo *repository.UserRepository,
	callbackSecret string,
	checkoutURLTemplate string,
) *RechargeService {
	return &RechargeService{
		pool:                pool,
		userRepo:            userRepo,
		callbackSecret:      strings.TrimSpace(callbackSecret),
		checkoutURLTemplate: strings.TrimSpace(checkoutURLTemplate),
	}
}

type RechargeProduct struct {
	ID          int64   `json:"id"`
	Code        string  `json:"code"`
	Credit      int     `json:"creditAmount"`
	SpiritStone int64   `json:"spiritStones"`
	BonusRate   float64 `json:"bonusRate"`
	Enabled     bool    `json:"enabled"`
}

type RechargeProductListResult struct {
	Products []RechargeProduct `json:"products"`
}

type RechargeOrder struct {
	ID              int64      `json:"id"`
	UserID          uuid.UUID  `json:"-"`
	ProductCode     string     `json:"productCode"`
	CreditAmount    int        `json:"creditAmount"`
	SpiritStones    int64      `json:"spiritStones"`
	ExternalOrderID string     `json:"externalOrderId,omitempty"`
	Status          string     `json:"status"`
	IdempotencyKey  string     `json:"idempotencyKey,omitempty"`
	CreatedAt       time.Time  `json:"createdAt"`
	PaidAt          *time.Time `json:"paidAt,omitempty"`
	UpdatedAt       time.Time  `json:"updatedAt"`
}

type RechargeOrderListResult struct {
	Orders []RechargeOrder `json:"orders"`
}

type RechargeCreateInput struct {
	ProductCode    string
	IdempotencyKey string
}

type RechargeCreateResult struct {
	Order       *RechargeOrder             `json:"order"`
	CheckoutURL string                     `json:"checkoutUrl,omitempty"`
	Snapshot    *repository.PlayerSnapshot `json:"snapshot,omitempty"`
}

type RechargeActionResult struct {
	Message  string                     `json:"message"`
	Credited bool                       `json:"credited"`
	Order    *RechargeOrder             `json:"order,omitempty"`
	Snapshot *repository.PlayerSnapshot `json:"snapshot,omitempty"`
}

type RechargeCallbackResult struct {
	Accepted       bool           `json:"accepted"`
	SignatureValid bool           `json:"signatureValid"`
	Credited       bool           `json:"credited"`
	Order          *RechargeOrder `json:"order,omitempty"`
}

type RechargeProductNotFoundError struct {
	ProductCode string
}

func (e *RechargeProductNotFoundError) Error() string {
	return fmt.Sprintf("recharge product not found: %s", e.ProductCode)
}

type RechargeProductDisabledError struct {
	ProductCode string
}

func (e *RechargeProductDisabledError) Error() string {
	return fmt.Sprintf("recharge product disabled: %s", e.ProductCode)
}

type RechargeOrderNotFoundError struct {
	OrderID         int64
	ExternalOrderID string
}

func (e *RechargeOrderNotFoundError) Error() string {
	if e.OrderID > 0 {
		return fmt.Sprintf("recharge order not found: %d", e.OrderID)
	}
	return fmt.Sprintf("recharge order not found by external id: %s", e.ExternalOrderID)
}

type RechargeOrderForbiddenError struct {
	OrderID int64
}

func (e *RechargeOrderForbiddenError) Error() string {
	return fmt.Sprintf("recharge order forbidden: %d", e.OrderID)
}

type RechargeInvalidCallbackSignatureError struct{}

func (e *RechargeInvalidCallbackSignatureError) Error() string {
	return "invalid recharge callback signature"
}

type RechargeInvalidCallbackPayloadError struct {
	Reason string
}

func (e *RechargeInvalidCallbackPayloadError) Error() string {
	return fmt.Sprintf("invalid recharge callback payload: %s", e.Reason)
}

type RechargeIdempotencyConflictError struct {
	IdempotencyKey string
}

func (e *RechargeIdempotencyConflictError) Error() string {
	return fmt.Sprintf("recharge idempotency key conflict: %s", e.IdempotencyKey)
}

func (s *RechargeService) ListProducts(ctx context.Context, includeDisabled bool) (*RechargeProductListResult, error) {
	const query = `
		SELECT id, code, credit_amount, spirit_stones, bonus_rate, enabled
		FROM recharge_products
		WHERE ($1 OR enabled = TRUE)
		ORDER BY credit_amount ASC, id ASC
	`

	rows, err := s.pool.Query(ctx, query, includeDisabled)
	if err != nil {
		return nil, fmt.Errorf("query recharge products: %w", err)
	}
	defer rows.Close()

	products := make([]RechargeProduct, 0, 8)
	for rows.Next() {
		product := RechargeProduct{}
		if err := rows.Scan(
			&product.ID,
			&product.Code,
			&product.Credit,
			&product.SpiritStone,
			&product.BonusRate,
			&product.Enabled,
		); err != nil {
			return nil, fmt.Errorf("scan recharge product row: %w", err)
		}
		products = append(products, product)
	}
	if rows.Err() != nil {
		return nil, fmt.Errorf("iterate recharge products rows: %w", rows.Err())
	}

	return &RechargeProductListResult{Products: products}, nil
}

func (s *RechargeService) ListOrders(ctx context.Context, userID uuid.UUID, limit int) (*RechargeOrderListResult, error) {
	if limit <= 0 {
		limit = 20
	}
	if limit > 100 {
		limit = 100
	}

	const query = `
		SELECT
			id,
			user_id,
			product_code,
			credit_amount,
			spirit_stones,
			COALESCE(external_order_id, ''),
			status,
			idempotency_key,
			created_at,
			paid_at,
			updated_at
		FROM recharge_orders
		WHERE user_id = $1
		ORDER BY created_at DESC, id DESC
		LIMIT $2
	`

	rows, err := s.pool.Query(ctx, query, userID, limit)
	if err != nil {
		return nil, fmt.Errorf("query recharge orders: %w", err)
	}
	defer rows.Close()

	orders := make([]RechargeOrder, 0, limit)
	for rows.Next() {
		order, scanErr := scanRechargeOrder(rows)
		if scanErr != nil {
			return nil, scanErr
		}
		orders = append(orders, order)
	}
	if rows.Err() != nil {
		return nil, fmt.Errorf("iterate recharge orders rows: %w", rows.Err())
	}

	return &RechargeOrderListResult{Orders: orders}, nil
}

func (s *RechargeService) CreateOrder(ctx context.Context, userID uuid.UUID, input RechargeCreateInput) (*RechargeCreateResult, error) {
	productCode := strings.TrimSpace(input.ProductCode)
	if productCode == "" {
		return nil, &RechargeProductNotFoundError{ProductCode: productCode}
	}

	idempotencyKey := strings.TrimSpace(input.IdempotencyKey)
	if idempotencyKey == "" {
		idempotencyKey = uuid.NewString()
	}

	tx, err := s.pool.Begin(ctx)
	if err != nil {
		return nil, fmt.Errorf("begin recharge create transaction: %w", err)
	}
	defer func() { _ = tx.Rollback(ctx) }()

	product, err := loadRechargeProductForCreateTx(ctx, tx, productCode)
	if err != nil {
		return nil, err
	}
	if !product.Enabled {
		return nil, &RechargeProductDisabledError{ProductCode: productCode}
	}

	order, err := insertRechargeOrderTx(ctx, tx, userID, product, idempotencyKey)
	if err != nil {
		var pgErr *pgconn.PgError
		if errors.As(err, &pgErr) && pgErr.Code == pgUniqueViolationCode {
			existingOrder, loadErr := loadRechargeOrderByIdempotencyTx(ctx, tx, idempotencyKey)
			if loadErr != nil {
				return nil, loadErr
			}
			if existingOrder.UserID != userID {
				return nil, &RechargeIdempotencyConflictError{IdempotencyKey: idempotencyKey}
			}

			snapshot, snapErr := s.userRepo.GetSnapshot(ctx, userID)
			if snapErr != nil {
				return nil, snapErr
			}

			return &RechargeCreateResult{
				Order:       existingOrder,
				CheckoutURL: s.buildCheckoutURL(existingOrder),
				Snapshot:    snapshot,
			}, nil
		}
		return nil, err
	}

	if order.ExternalOrderID == "" {
		order.ExternalOrderID = fmt.Sprintf("rx_%d_%s", order.ID, uuid.NewString()[:8])
		const updateSQL = `
			UPDATE recharge_orders
			SET external_order_id = $2, updated_at = now()
			WHERE id = $1
			RETURNING updated_at
		`
		if updateErr := tx.QueryRow(ctx, updateSQL, order.ID, order.ExternalOrderID).Scan(&order.UpdatedAt); updateErr != nil {
			return nil, fmt.Errorf("update recharge external order id: %w", updateErr)
		}
	}

	if err := tx.Commit(ctx); err != nil {
		return nil, fmt.Errorf("commit recharge create transaction: %w", err)
	}

	snapshot, err := s.userRepo.GetSnapshot(ctx, userID)
	if err != nil {
		return nil, err
	}

	return &RechargeCreateResult{
		Order:       order,
		CheckoutURL: s.buildCheckoutURL(order),
		Snapshot:    snapshot,
	}, nil
}

func (s *RechargeService) HandleCreditLinuxDoCallback(
	ctx context.Context,
	payloadRaw []byte,
	signature string,
) (*RechargeCallbackResult, error) {
	preparedPayload, payload, payloadErr := prepareRechargeCallbackPayload(payloadRaw)
	signatureValid := s.validateCallbackSignature(payloadRaw, signature)

	externalOrderID := firstNonEmptyString(
		readCallbackString(payload, "externalOrderId"),
		readCallbackString(payload, "external_order_id"),
		readCallbackString(payload, "orderId"),
		readCallbackString(payload, "order_id"),
		readCallbackString(payload, "outTradeNo"),
		readCallbackString(payload, "out_trade_no"),
	)
	statusRaw := firstNonEmptyString(
		readCallbackString(payload, "status"),
		readCallbackString(payload, "tradeStatus"),
		readCallbackString(payload, "trade_status"),
	)
	normalizedStatus := normalizeRechargeStatus(statusRaw)
	paidAt := readCallbackTime(payload, "paidAt", "paid_at", "payTime", "pay_time")

	tx, err := s.pool.Begin(ctx)
	if err != nil {
		return nil, fmt.Errorf("begin recharge callback transaction: %w", err)
	}
	defer func() { _ = tx.Rollback(ctx) }()

	const insertCallbackSQL = `
		INSERT INTO recharge_callbacks (external_order_id, payload, signature_valid, received_at)
		VALUES (NULLIF($1, ''), $2::jsonb, $3, now())
	`
	if _, err := tx.Exec(ctx, insertCallbackSQL, externalOrderID, string(preparedPayload), signatureValid); err != nil {
		return nil, fmt.Errorf("insert recharge callback: %w", err)
	}

	if !signatureValid {
		if err := tx.Commit(ctx); err != nil {
			return nil, fmt.Errorf("commit recharge callback with invalid signature: %w", err)
		}
		return nil, &RechargeInvalidCallbackSignatureError{}
	}

	if payloadErr != nil {
		if err := tx.Commit(ctx); err != nil {
			return nil, fmt.Errorf("commit recharge callback with invalid payload: %w", err)
		}
		return nil, payloadErr
	}

	if externalOrderID == "" {
		if err := tx.Commit(ctx); err != nil {
			return nil, fmt.Errorf("commit recharge callback without external order id: %w", err)
		}
		return nil, &RechargeInvalidCallbackPayloadError{Reason: "missing externalOrderId"}
	}

	order, err := loadRechargeOrderForUpdateByExternalIDTx(ctx, tx, externalOrderID)
	if err != nil {
		if errors.Is(err, pgx.ErrNoRows) {
			if commitErr := tx.Commit(ctx); commitErr != nil {
				return nil, fmt.Errorf("commit recharge callback unknown order: %w", commitErr)
			}
			return nil, &RechargeOrderNotFoundError{ExternalOrderID: externalOrderID}
		}
		return nil, err
	}

	credited := false
	if normalizedStatus == rechargeStatusPaid {
		credited, err = markRechargeOrderPaidTx(ctx, tx, order, paidAt)
		if err != nil {
			return nil, err
		}
	} else if normalizedStatus != "" {
		if err := updateRechargeOrderStatusTx(ctx, tx, order, normalizedStatus); err != nil {
			return nil, err
		}
	}

	if err := tx.Commit(ctx); err != nil {
		return nil, fmt.Errorf("commit recharge callback transaction: %w", err)
	}

	return &RechargeCallbackResult{
		Accepted:       true,
		SignatureValid: true,
		Credited:       credited,
		Order:          order,
	}, nil
}

func (s *RechargeService) MockMarkPaid(ctx context.Context, userID uuid.UUID, orderID int64) (*RechargeActionResult, error) {
	tx, err := s.pool.Begin(ctx)
	if err != nil {
		return nil, fmt.Errorf("begin recharge mock paid transaction: %w", err)
	}
	defer func() { _ = tx.Rollback(ctx) }()

	order, err := loadRechargeOrderForUpdateByIDTx(ctx, tx, orderID)
	if err != nil {
		if errors.Is(err, pgx.ErrNoRows) {
			return nil, &RechargeOrderNotFoundError{OrderID: orderID}
		}
		return nil, err
	}
	if order.UserID != userID {
		return nil, &RechargeOrderForbiddenError{OrderID: orderID}
	}

	credited, err := markRechargeOrderPaidTx(ctx, tx, order, time.Now().UTC())
	if err != nil {
		return nil, err
	}

	if err := tx.Commit(ctx); err != nil {
		return nil, fmt.Errorf("commit recharge mock paid transaction: %w", err)
	}

	snapshot, err := s.userRepo.GetSnapshot(ctx, userID)
	if err != nil {
		return nil, err
	}

	message := "订单已是支付成功状态"
	if credited {
		message = "模拟支付成功，灵石已到账"
	}

	return &RechargeActionResult{
		Message:  message,
		Credited: credited,
		Order:    order,
		Snapshot: snapshot,
	}, nil
}

func (s *RechargeService) buildCheckoutURL(order *RechargeOrder) string {
	if order == nil || s.checkoutURLTemplate == "" {
		return ""
	}
	url := s.checkoutURLTemplate
	replacements := map[string]string{
		"{order_id}":          strconv.FormatInt(order.ID, 10),
		"{user_id}":           order.UserID.String(),
		"{product_code}":      order.ProductCode,
		"{credit_amount}":     strconv.Itoa(order.CreditAmount),
		"{spirit_stones}":     strconv.FormatInt(order.SpiritStones, 10),
		"{external_order_id}": order.ExternalOrderID,
	}
	for placeholder, value := range replacements {
		url = strings.ReplaceAll(url, placeholder, value)
	}
	return url
}

func (s *RechargeService) validateCallbackSignature(payload []byte, header string) bool {
	if s.callbackSecret == "" {
		return true
	}
	received := strings.TrimSpace(strings.ToLower(header))
	received = strings.TrimPrefix(received, "sha256=")
	if received == "" {
		return false
	}

	mac := hmac.New(sha256.New, []byte(s.callbackSecret))
	mac.Write(payload)
	expected := hex.EncodeToString(mac.Sum(nil))
	return hmac.Equal([]byte(received), []byte(expected))
}

func prepareRechargeCallbackPayload(payloadRaw []byte) ([]byte, map[string]any, *RechargeInvalidCallbackPayloadError) {
	trimmed := bytes.TrimSpace(payloadRaw)
	if len(trimmed) == 0 {
		fallback, _ := json.Marshal(map[string]any{
			"raw":          "",
			"invalid_json": true,
		})
		return fallback, map[string]any{}, &RechargeInvalidCallbackPayloadError{Reason: "empty payload"}
	}

	payload := make(map[string]any)
	if err := json.Unmarshal(trimmed, &payload); err != nil {
		fallback, _ := json.Marshal(map[string]any{
			"raw":          string(trimmed),
			"invalid_json": true,
		})
		return fallback, map[string]any{}, &RechargeInvalidCallbackPayloadError{Reason: "invalid json"}
	}

	return trimmed, payload, nil
}

func loadRechargeProductForCreateTx(ctx context.Context, tx pgx.Tx, code string) (*RechargeProduct, error) {
	const query = `
		SELECT id, code, credit_amount, spirit_stones, bonus_rate, enabled
		FROM recharge_products
		WHERE code = $1
	`

	product := &RechargeProduct{}
	if err := tx.QueryRow(ctx, query, code).Scan(
		&product.ID,
		&product.Code,
		&product.Credit,
		&product.SpiritStone,
		&product.BonusRate,
		&product.Enabled,
	); err != nil {
		if errors.Is(err, pgx.ErrNoRows) {
			return nil, &RechargeProductNotFoundError{ProductCode: code}
		}
		return nil, fmt.Errorf("load recharge product: %w", err)
	}
	return product, nil
}

func insertRechargeOrderTx(
	ctx context.Context,
	tx pgx.Tx,
	userID uuid.UUID,
	product *RechargeProduct,
	idempotencyKey string,
) (*RechargeOrder, error) {
	const insertSQL = `
		INSERT INTO recharge_orders (
			user_id,
			product_code,
			credit_amount,
			spirit_stones,
			status,
			idempotency_key,
			created_at,
			updated_at
		)
		VALUES ($1, $2, $3, $4, $5, $6, now(), now())
		RETURNING
			id,
			user_id,
			product_code,
			credit_amount,
			spirit_stones,
			COALESCE(external_order_id, ''),
			status,
			idempotency_key,
			created_at,
			paid_at,
			updated_at
	`

	row := tx.QueryRow(
		ctx,
		insertSQL,
		userID,
		product.Code,
		product.Credit,
		product.SpiritStone,
		rechargeStatusPending,
		idempotencyKey,
	)
	order, err := scanRechargeOrder(row)
	if err != nil {
		return nil, err
	}
	return &order, nil
}

func loadRechargeOrderByIdempotencyTx(ctx context.Context, tx pgx.Tx, idempotencyKey string) (*RechargeOrder, error) {
	const query = `
		SELECT
			id,
			user_id,
			product_code,
			credit_amount,
			spirit_stones,
			COALESCE(external_order_id, ''),
			status,
			idempotency_key,
			created_at,
			paid_at,
			updated_at
		FROM recharge_orders
		WHERE idempotency_key = $1
	`
	row := tx.QueryRow(ctx, query, idempotencyKey)
	order, err := scanRechargeOrder(row)
	if err != nil {
		if errors.Is(err, pgx.ErrNoRows) {
			return nil, &RechargeOrderNotFoundError{}
		}
		return nil, err
	}
	return &order, nil
}

func loadRechargeOrderForUpdateByExternalIDTx(ctx context.Context, tx pgx.Tx, externalOrderID string) (*RechargeOrder, error) {
	const query = `
		SELECT
			id,
			user_id,
			product_code,
			credit_amount,
			spirit_stones,
			COALESCE(external_order_id, ''),
			status,
			idempotency_key,
			created_at,
			paid_at,
			updated_at
		FROM recharge_orders
		WHERE external_order_id = $1
		FOR UPDATE
	`
	row := tx.QueryRow(ctx, query, externalOrderID)
	order, err := scanRechargeOrder(row)
	if err != nil {
		return nil, err
	}
	return &order, nil
}

func loadRechargeOrderForUpdateByIDTx(ctx context.Context, tx pgx.Tx, orderID int64) (*RechargeOrder, error) {
	const query = `
		SELECT
			id,
			user_id,
			product_code,
			credit_amount,
			spirit_stones,
			COALESCE(external_order_id, ''),
			status,
			idempotency_key,
			created_at,
			paid_at,
			updated_at
		FROM recharge_orders
		WHERE id = $1
		FOR UPDATE
	`
	row := tx.QueryRow(ctx, query, orderID)
	order, err := scanRechargeOrder(row)
	if err != nil {
		return nil, err
	}
	return &order, nil
}

func markRechargeOrderPaidTx(ctx context.Context, tx pgx.Tx, order *RechargeOrder, paidAt time.Time) (bool, error) {
	if order == nil {
		return false, fmt.Errorf("mark recharge order paid: empty order")
	}
	if order.Status == rechargeStatusPaid {
		return false, nil
	}

	currentBalance, err := loadRechargeSpiritStonesForUpdateTx(ctx, tx, order.UserID)
	if err != nil {
		return false, err
	}
	nextBalance := currentBalance + order.SpiritStones

	if err := updateRechargeSpiritStonesTx(ctx, tx, order.UserID, nextBalance); err != nil {
		return false, err
	}
	if err := insertRechargeEconomyLogTx(ctx, tx, order.UserID, "recharge_paid", order.SpiritStones, nextBalance, fmt.Sprintf("recharge_order:%d", order.ID)); err != nil {
		return false, err
	}

	if paidAt.IsZero() {
		paidAt = time.Now().UTC()
	}

	const updateOrderSQL = `
		UPDATE recharge_orders
		SET status = $2, paid_at = COALESCE(paid_at, $3), updated_at = now()
		WHERE id = $1
		RETURNING paid_at, updated_at
	`
	var paidAtValue sql.NullTime
	if err := tx.QueryRow(ctx, updateOrderSQL, order.ID, rechargeStatusPaid, paidAt).Scan(&paidAtValue, &order.UpdatedAt); err != nil {
		return false, fmt.Errorf("update recharge order paid status: %w", err)
	}

	order.Status = rechargeStatusPaid
	if paidAtValue.Valid {
		ts := paidAtValue.Time.UTC()
		order.PaidAt = &ts
	}
	return true, nil
}

func updateRechargeOrderStatusTx(ctx context.Context, tx pgx.Tx, order *RechargeOrder, status string) error {
	if order == nil {
		return fmt.Errorf("update recharge order status: empty order")
	}
	if order.Status == rechargeStatusPaid {
		return nil
	}
	if status == "" || status == order.Status {
		return nil
	}

	const query = `
		UPDATE recharge_orders
		SET status = $2, updated_at = now()
		WHERE id = $1
		RETURNING updated_at
	`
	if err := tx.QueryRow(ctx, query, order.ID, status).Scan(&order.UpdatedAt); err != nil {
		return fmt.Errorf("update recharge order status: %w", err)
	}
	order.Status = status
	return nil
}

func loadRechargeSpiritStonesForUpdateTx(ctx context.Context, tx pgx.Tx, userID uuid.UUID) (int64, error) {
	const query = `
		SELECT spirit_stones
		FROM player_resources
		WHERE user_id = $1
		FOR UPDATE
	`
	var value int64
	if err := tx.QueryRow(ctx, query, userID).Scan(&value); err != nil {
		return 0, fmt.Errorf("load spirit stones for recharge: %w", err)
	}
	return value, nil
}

func updateRechargeSpiritStonesTx(ctx context.Context, tx pgx.Tx, userID uuid.UUID, value int64) error {
	const query = `
		UPDATE player_resources
		SET spirit_stones = $2, updated_at = now()
		WHERE user_id = $1
	`
	if _, err := tx.Exec(ctx, query, userID, value); err != nil {
		return fmt.Errorf("update spirit stones for recharge: %w", err)
	}
	return nil
}

func insertRechargeEconomyLogTx(
	ctx context.Context,
	tx pgx.Tx,
	userID uuid.UUID,
	changeType string,
	amount int64,
	balanceAfter int64,
	detail string,
) error {
	const query = `
		INSERT INTO economy_logs (user_id, currency, change_type, amount, balance_after, detail, occurred_at)
		VALUES ($1, 'spirit_stones', $2, $3, $4, $5, now())
	`
	if _, err := tx.Exec(ctx, query, userID, changeType, amount, balanceAfter, detail); err != nil {
		return fmt.Errorf("insert recharge economy log: %w", err)
	}
	return nil
}

type rechargeOrderScanner interface {
	Scan(dest ...any) error
}

func scanRechargeOrder(scanner rechargeOrderScanner) (RechargeOrder, error) {
	order := RechargeOrder{}
	var (
		paidAt sql.NullTime
	)
	if err := scanner.Scan(
		&order.ID,
		&order.UserID,
		&order.ProductCode,
		&order.CreditAmount,
		&order.SpiritStones,
		&order.ExternalOrderID,
		&order.Status,
		&order.IdempotencyKey,
		&order.CreatedAt,
		&paidAt,
		&order.UpdatedAt,
	); err != nil {
		return RechargeOrder{}, fmt.Errorf("scan recharge order row: %w", err)
	}
	if paidAt.Valid {
		ts := paidAt.Time.UTC()
		order.PaidAt = &ts
	}
	return order, nil
}

func readCallbackString(payload map[string]any, key string) string {
	if payload == nil {
		return ""
	}
	raw, ok := payload[key]
	if !ok || raw == nil {
		return ""
	}
	switch value := raw.(type) {
	case string:
		return strings.TrimSpace(value)
	case float64:
		return strings.TrimSpace(strconv.FormatFloat(value, 'f', -1, 64))
	case int64:
		return strings.TrimSpace(strconv.FormatInt(value, 10))
	case int:
		return strings.TrimSpace(strconv.Itoa(value))
	default:
		return strings.TrimSpace(fmt.Sprintf("%v", value))
	}
}

func readCallbackTime(payload map[string]any, keys ...string) time.Time {
	for _, key := range keys {
		raw := readCallbackString(payload, key)
		if raw == "" {
			continue
		}

		if unixSeconds, err := strconv.ParseInt(raw, 10, 64); err == nil {
			if unixSeconds > 1_000_000_000_000 {
				return time.UnixMilli(unixSeconds).UTC()
			}
			if unixSeconds > 0 {
				return time.Unix(unixSeconds, 0).UTC()
			}
		}

		layouts := []string{
			time.RFC3339,
			"2006-01-02 15:04:05",
			"2006-01-02T15:04:05",
		}
		for _, layout := range layouts {
			if ts, err := time.Parse(layout, raw); err == nil {
				return ts.UTC()
			}
		}
	}
	return time.Time{}
}

func firstNonEmptyString(values ...string) string {
	for _, value := range values {
		trimmed := strings.TrimSpace(value)
		if trimmed != "" {
			return trimmed
		}
	}
	return ""
}

func normalizeRechargeStatus(raw string) string {
	status := strings.ToLower(strings.TrimSpace(raw))
	switch status {
	case "":
		return rechargeStatusPending
	case "paid", "success", "succeed", "succeeded", "completed", "complete", "trade_success", "trade-success":
		return rechargeStatusPaid
	case "failed", "fail", "error", "closed", "expired":
		return rechargeStatusFailed
	case "cancel", "cancelled", "canceled":
		return rechargeStatusCancelled
	default:
		return status
	}
}
