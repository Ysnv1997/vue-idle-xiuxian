<template>
  <section class="page-view settings-view">
    <header class="page-head">
      <p class="page-eyebrow">洞府设置</p>
      <h2>游戏设置</h2>
      <p class="page-desc">查看版本信息与社区入口。</p>
    </header>

    <n-card :bordered="false" class="page-card">
      <template #header-extra>游戏版本 {{ version }}</template>
      <n-space vertical>
        <n-alert type="info" :show-icon="false">
          当前版本：<strong>{{ version }}</strong>
        </n-alert>
        <n-space>
          <n-button tertiary @click="qq = true">玩家交流群</n-button>
        </n-space>
      </n-space>
    </n-card>

    <n-modal preset="dialog" title="玩家交流群" v-model:show="qq">
      <n-card :bordered="false" size="huge" role="dialog" aria-modal="true">
        <n-space vertical>
          <n-text depth="3">QQ群号</n-text>
          <n-input value="920930589" readonly type="text" />
        </n-space>
      </n-card>
    </n-modal>
  </section>
</template>

<script setup>
  import { ref } from 'vue'

  const version = __APP_VERSION__
  const qq = ref(false)
</script>
